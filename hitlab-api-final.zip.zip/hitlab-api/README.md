﻿# HitLab API Quickstart
1) Copy-Item .env.example .env
2) npm install
3) npm run dev
4) open http://localhost:8080/health
